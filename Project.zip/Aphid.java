import java.util.Random;

public class Aphid extends Insect {

	private static final int MAX_AGE = 15;
	//private InsectSimulation insectSim;
	
	public Aphid() {
		
		super(randomNumber(), randomNumber());
		this.setAge(1);
	}
	
	public static int randomNumber() {
		
		Random rand = new Random();
		return rand.nextInt(50);
		
		
	}
	
	
	@Override
	public void move() {
		
		int newX = getX();
		int newY = getY();
		
		
		this.setAge(getAge() + 1);									//Quickly Increments the age with a move
		
		//Choose a direction to move (0 - 4)
		Random rand = new Random();
		int moveDirection = rand.nextInt(5);
		
		if(moveDirection == 1) {
			newY--;
			
		}
		else if (moveDirection == 2){
			newY++;
		}
		else if (moveDirection == 3) {
			newX--;
			
		}
		else if (moveDirection == 4) {
			newX++;
		}
		
		setPosition(newX, newY);
		
		
	}
	
	@Override
	public boolean isDead() {
		return getAge() > MAX_AGE;
	}
	
	@Override
	public boolean reproduce() {
		
		if(getAge() % 5 == 0) {
			
			return true;
		}
		
		return false;
		
	}
}





