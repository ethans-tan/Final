
public abstract class Insect {

	private int age;
	private int xPosition;
	private int yPosition;
	
	//Constructor
	public Insect(int X, int Y) {
		
		this.xPosition = X;
		this.yPosition = Y;
		
	}
	
	//Abstract methods
	public abstract void move();
	
	public abstract boolean isDead();
	
	public abstract boolean reproduce();
	
	
	public int getAge() {
		return age;
	}
	
	public void setAge(int a) {
		age = a;
		
	}
	
	public int getX() {
		return xPosition;
		
	}
	
	public int getY() {
		return yPosition;
		
	}
	
	public void setPosition(int x, int y) {
		xPosition = x;
		yPosition = y;
	}
	
	
	
}
