import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class SimulationGui extends JPanel implements ActionListener{

	
	private static final long serialVersionUID = 1L;
	private int gridSquare = 10;
	private int gridWidth = 50;
	private int gridHeight = 50;
	private InsectSimulation sim;
	
	
	public SimulationGui(int numAphids, int numBeetles) {
		sim = new InsectSimulation(gridWidth, gridHeight);
		for (int i = 0; i < numAphids; i++) {
			sim.addInsect(new Aphid());
		}
		
		for(int i = 0; i < numBeetles; i++) {
			sim.addInsect(new Beetle(15));
		}
		
	
		
	}
	
	public Dimension getPreferredSize() {
		
		return new Dimension(gridSquare * gridWidth, gridSquare * gridHeight);
		
	}
	
	protected void paintComponent(Graphics g) {
		super.paintComponent(g); 
		for(int i = 0; i < gridWidth; i++) {
			for(int j = 0; j < gridHeight; j++) {
				Insect bug = sim.getInsectAt(i,j);
				if(bug == null) {
					g.setColor(Color.WHITE);
					
				}
				else {
					if(bug instanceof Aphid) {
						g.setColor(Color.RED);
						
					}
					if(bug instanceof Beetle) {
						g.setColor(Color.BLACK);
					}
				}
				
				g.fillRect(i*gridSquare,  j* gridSquare, gridSquare, gridSquare);
			}
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if("stepCommand".equals(e.getActionCommand())) {
		
			System.out.println("clicked");
			sim.simulationStep();
			this.repaint();
			
		}
		else {
			System.out.println("no");
		}
		
	}
	
	 public static void main(String[] args) {
	        // Create a JFrame
	        JFrame frame = new JFrame("Insect Simulation");

	        // Set the JFrame to use the GridBagLayout
	        frame.setLayout(new GridBagLayout());

	        // Create a SimulationGui object
	        SimulationGui simulationGui = new SimulationGui(10, 5); // Adjust the numbers as needed

	        // Create a gridBagConstraints object
	        GridBagConstraints gbc = new GridBagConstraints();

	        // Set the parameters of GridBagConstraints for the simulationGui object
	        gbc.gridx = 0;
	        gbc.gridy = 0;
	        gbc.gridwidth = 1;
	        gbc.gridheight = 1;
	        gbc.weightx = 1.0;
	        gbc.weighty = 1.0;
	        gbc.fill = GridBagConstraints.BOTH;

	        // Add the simulationGui to the outer JFrame
	        frame.add(simulationGui, gbc);

	        // Create a JButton
	        JButton button = new JButton("Step");
	        button.setActionCommand("stepCommand");
	        button.addActionListener(simulationGui);
	        
	       
	        // Set the parameters of GridBagConstraints for the JButton
	        gbc.gridx = 0;
	        gbc.gridy = 1;
	        gbc.gridwidth = 1;
	        gbc.gridheight = 1;
	        gbc.weightx = 0.0;
	        gbc.weighty = 0.0;
	        gbc.fill = GridBagConstraints.HORIZONTAL;

	        // Add the JButton to the outer JFrame
	        frame.add(button, gbc);
	        

	        // Set the JFrame's default close operation, pack it, and set it to visible
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        frame.pack();
	        frame.setVisible(true);
	    }
	
}
