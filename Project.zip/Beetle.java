import java.util.Random;

public class Beetle extends Insect{
	
	private static final int MAX_AGE = 40;
	private static final int MAX_CAP = 40;
	private InsectSimulation insectSim;
	
	
	private int stomach;
	

	public Beetle(int stomach2) {

		super(randomNumber(), randomNumber());
		this.stomach = stomach2;
		this.setAge(1);
		
		
	}

	public static int randomNumber() {
		
		Random rand = new Random();
		return rand.nextInt(50);
		
	}
	
	@Override
	public void move() {
		
		int newX = getX();
		int newY = getY();
		
		this.setAge(getAge() + 1);									//Quickly Increments the age with a move
		this.setStomach(getStomach() - 1);
		
		//Choose a direction to move (0 - 4)
		Random rand = new Random();
		int moveDirection = rand.nextInt(5);
		
		if(moveDirection == 1) {
			newY--;
			
		}
		else if (moveDirection == 2){
			newY++;
		}
		else if (moveDirection == 3) {
			newX--;
			
		}
		else if (moveDirection == 4) {
			newX++;
		}
		
		setPosition(newX, newY);
		
		
		/*
		Insect temp = insectSim.getInsectAt(newX, newY);
		if(temp instanceof Aphid) {
			eatAphid((Aphid) temp );
			
		}*/
		
		
	}

	private void eatAphid(Insect aphid) {
		
		insectSim.removeInsect(aphid);
		stomach += 5 + new Random().nextInt(6); // Random value between 5 and 10
		
	}
	
	public boolean isDead() {
		return getAge() > MAX_AGE || stomach <= 0;
	}
	
	public boolean reproduce() {
		
		if (stomach > MAX_CAP * 0.8) {
           
			return true;
            
            }
		
		 return false;
    }
	
	public int getStomach() {
		return stomach;
		
	}
	
	public void setStomach(int stomach) {
		this.stomach = stomach;
		
	}
	

       
}

	
	    

