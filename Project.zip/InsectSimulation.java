import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class InsectSimulation {

	private int areaWidth;
	private int areaHeight;
	private static Insect[][] simulationArea;
	private ArrayList<Insect> insects;
	
	//constructor
	public InsectSimulation(int w, int h) {
		
		areaWidth = w;
		areaHeight = h;
		simulationArea = new Insect[w][h];
		insects = new ArrayList<>();
	
	}
	
	public int getAreaWidth() {
		return areaWidth;
		
	}
	
	public int getAreaHeight() {
		return areaHeight;
		
	}
	
	public void addInsect(Insect insect, int x, int y) {
		
		//sets insect there if there is white space
		if(simulationArea[x][y] == null) {
			simulationArea[x][y] = insect;
			insect.setPosition(x,y);
			insects.add(insect);
		}
		
		else {
			
		}
		
	}
	
	public void addInsect(Insect insect) {
	    	
		Random rand = new Random();
		int x = rand.nextInt(areaWidth);
		int y = rand.nextInt(areaHeight);
		addInsect(insect, x, y);
		
	}
	
	public Insect getInsectAt(int x, int y) {
		return simulationArea[x][y];
		
	}
	
	public void removeInsect(Insect insect) {
		
		insects.remove(insect);
		
	}
	
	public void simulationStep() {
		
		// Move all insects
		 for (Insect insect : insects) {
			 insect.move();
	     
		 }
		 
		 
        //check to see if the Insects can reproduce
        ArrayList<Insect> newInsects = new ArrayList<>();
        Iterator<Insect> iter = insects.iterator();
        
        while(iter.hasNext()) {
        	Insect current = iter.next();
        	
        	 current.move();
        	 
        	
        	if(current.reproduce()) {
        	
        		Insect newInsect = createChild(current);
        		
        		int newX = current.getX();
        		int newY = current.getY();
        		
        		if(check(newX + 1, newY)) {
        			newX = newX + 1;
        			
        		}
        		else if(check(newX - 1, newY)) {
        			newX = newX -1;
        			
        		}
        		else if(check(newX, newY + 1)) {
        			newY = newY + 1;
        		}
        		else if(check(newX, newY -1)){
        			newY = newY - 1;
        			
        		}
        		else {
        			continue;
        		}
        		
        		
        		newInsect.setPosition(newX, newY);
        		newInsects.add(newInsect);
        		
        	}
        	
        }
        
        insects.addAll(newInsects);

        
        // Remove dead insects
        insects.removeIf(Insect::isDead);
       
    }
	
	private Insect createChild(Insect parent) {
		
		if(parent instanceof Aphid) {
			return new Aphid();
			
		}
		else if(parent instanceof Beetle) {
			return new Beetle(15);
			
		}
		
		return null;
		
	}
	
	private Boolean check(int x, int y) {
	
		if(x >= 0 && x < areaWidth && y >= 0 && y <= areaHeight){
			
			for(Insect insect : insects) {
				if(insect.getX() == x && insect.getY() == y) {
					return false;
					
				}
			}
			return true;
			
		}
		
		return false;
		
	}
	
	
}
